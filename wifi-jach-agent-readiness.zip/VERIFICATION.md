# Wifi Jach agent-readiness implementation checks

- PASS — robots allows ChatGPT-User
- PASS — robots allows ClaudeBot
- PASS — robots allows Google-Extended
- PASS — robots allows DeepSeekBot
- PASS — sitemap is XML-shaped
- PASS — sitemap lists homepage
- PASS — 404 recovery links
- PASS — llms when-to-use
- PASS — llms canonical
- PASS — JSON-LD SoftwareApplication
- PASS — JSON-LD Organization
- PASS — canonical
- PASS — og:type
- PASS — og:image
- PASS — html lang

## Important deployment-dependent checks

- AI crawler reachability must be re-tested after deployment; robots.txt cannot override a network/WAF block.
- GitHub Pages should serve 404.html with HTTP 404 for nonexistent paths.
- The homepage needs the supplied head patch inserted into the existing index.html.
- Accept: text/markdown negotiation with `Vary: Accept, Accept-Encoding` cannot be implemented by static GitHub Pages alone. It needs an edge/server layer such as a Worker in front of the site.
- A contact email/phone was not invented. The Organization contactPoint therefore points to the contact page. If the project has a public contact email or phone, add it to the schema.
- Brand-search ranking/indexing is an external SEO outcome and cannot be guaranteed by code alone.
